from sqlalchemy import MetaData, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from app.config import settings

# Backward compatibility alias for AsyncSession
AsyncSession = Session

# Create sync engine (no greenlet needed)
engine = create_engine(
    settings.database_url.replace("postgresql+asyncpg://", "postgresql://").replace("sqlite+aiosqlite://", "sqlite://"),
    pool_pre_ping=True,
    echo=settings.debug,
    future=True
)

# Create sync session factory
SessionLocal = sessionmaker(
    bind=engine,
    expire_on_commit=False
)

# Compatibility wrapper for async-like behavior
class AsyncSessionWrapper:
    def __init__(self):
        self.session = None
    
    def __call__(self):
        return self
    
    def __enter__(self):
        self.session = SessionLocal()
        return self.session
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            self.session.close()
    
    async def __aenter__(self):
        self.session = SessionLocal()
        return self.session
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            self.session.close()

# Backward compatibility alias (for existing service files)
AsyncSessionLocal = AsyncSessionWrapper

# Create base class for models
Base = declarative_base()

# Dependency for getting database session (sync version)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Create metadata
metadata = MetaData()
