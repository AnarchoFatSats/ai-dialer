from sqlalchemy import MetaData, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from app.config import settings

# Create sync engine (no greenlet needed)
engine = create_engine(
    settings.database_url.replace("postgresql+asyncpg://", "postgresql://").replace("sqlite+aiosqlite://", "sqlite://"),
    pool_pre_ping=True,
    echo=settings.debug,
    future=True
)

# Create sync session factory
SessionLocal = sessionmaker(
    bind=engine,
    expire_on_commit=False
)

# Create base class for models
Base = declarative_base()

# Dependency for getting database session (sync version)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Create metadata
metadata = MetaData()
